"""
# 1D Hartree interaction

config = {
    'space':{'x':[-5,5,100]},
    'loop':{'Imax':1000,'precision':1e-6,'mix':0.05},
    'const':{'epsilon':1e-3},
    'rho':{'N':32},
    'Vint':{'name':'Hartree','coef':1},
}

dpft = PyDPFT(config)
Vext = 1e3*dpft.x ** 2
Vx,Vint,rho,N = dpft(Vext)
plot(dpft,Vx,Vint,rho)

# 2D Dipole-dipole interaction in momentum (p) space

config = {
    'space':{'x':[-5,5,50],'y':[-5,5,50]},
    'loop':{'Imax':1000,'precision':1e-6,'mix':0.05},
    'const':{'epsilon':1e-2,'mu':[0.7, 0.7]},
    'rho':{'N':32},
    'Vint':{'name':'Dipole-p','coef':.1},
}

dpft = PyDPFT(config)
Vext = dpft.xx**2 + dpft.yy**2
Vx,Vint,rho,N = dpft(Vext)
plot(dpft,Vx,Vint,rho)

# 3D Dipole-dipole interaction in position (x) space

config = {
    'space':{'x':[-5,5,20],'y':[-5,5,20],'z':[-5,5,20]},
    'loop':{'Imax':1000,'precision':1e-6,'mix':0.05},
    'const':{'epsilon':1e-2,'mu':[0.7, 0.7, 0]},
    'rho':{'N':32},
    'Vint':{'name':'Dipole-x','coef':5},
}

dpft = PyDPFT(config)
Vext = dpft.xx**2 + dpft.yy**2 + dpft.zz**2
Vx,Vint,rho,N = dpft(Vext)
plot(dpft,Vx,Vint,rho)
"""

import time
import matplotlib.pyplot as plt
import numpy as np
import torch as tc

GPU = tc.device("cuda:0" if tc.cuda.is_available() else "cpu")


def initVariables(o):
    print("PyDPFT: Written by Ding Ruiqi from NUS for his bachelor thesis")
    s = o.config["space"]
    c = o.config["const"]
    x = np.linspace(*s["x"])
    dx = x[1] - x[0]
    dim = 1
    o.dV = dx
    if "y" in s:
        y = np.linspace(*s["y"])
        dy = y[1] - y[0]
        dim = 2
        o.dV = dx * dy
    if "z" in s:
        z = np.linspace(*s["z"])
        dz = z[1] - z[0]
        dim = 3
        o.dV = dx * dy * dz
    o.dim = dim
    if dim == 1:
        o.x = x
        o.xx = x
        r = ((x[None, :] - x[:, None]) ** 2) ** 0.5
    elif dim == 2:
        xx, yy = np.meshgrid(x, y, sparse=True, indexing="ij")
        o.x, o.y = x, y
        o.xx, o.yy = xx, yy
        r = (
            (xx[None, None, :, :] - xx[:, :, None, None]) ** 2
            + (yy[None, None, :, :] - yy[:, :, None, None]) ** 2
        ) ** 0.5
    elif dim == 3:
        xx, yy, zz = np.meshgrid(x, y, z, sparse=True, indexing="ij")
        o.x, o.y, o.z = x, y, z
        o.xx, o.yy, o.zz = xx, yy, zz
        r = (
            (xx[None, None, None, :, :, :] - xx[:, :, :, None, None, None]) ** 2
            + (yy[None, None, None, :, :, :] - yy[:, :, :, None, None, None]) ** 2
            + (zz[None, None, None, :, :, :] - zz[:, :, :, None, None, None]) ** 2
        ) ** 0.5

    if "Hartree" in o.config["Vint"]["name"]:
        VhKernel = o.dV / (r + c["epsilon"])
        o.VhKernel = tc.from_numpy(VhKernel).to(GPU)
    elif "Dipole" in o.config["Vint"]["name"]:
        if dim == 2:
            mu2 = c["mu"][0] ** 2 + c["mu"][1] ** 2
            muDotR = c["mu"][0] * (xx[None, None, :, :] - xx[:, :, None, None]) + c[
                "mu"
            ][1] * (yy[None, None, :, :] - yy[:, :, None, None])
        elif dim == 3:
            mu2 = c["mu"][0] ** 2 + c["mu"][1] ** 2 + c["mu"][2] ** 2
            muDotR = (
                c["mu"][0]
                * (xx[None, None, None, :, :, :] - xx[:, :, :, None, None, None])
                + c["mu"][1]
                * (yy[None, None, None, :, :, :] - yy[:, :, :, None, None, None])
                + c["mu"][2]
                * (zz[None, None, None, :, :, :] - zz[:, :, :, None, None, None])
            )
        if dim != 1:
            Vdd_p_Kernel = o.dV * (muDotR**2 / (r**2 + c["epsilon"]) - mu2 / 3)
            o.Vdd_p_Kernel = tc.from_numpy(Vdd_p_Kernel).to(GPU)
            Vdd_x_Kernel = -o.dV * (
                muDotR**2 / (r**5 + c["epsilon"])
                - mu2 / 3 / (r**3 + c["epsilon"])
            )
            o.Vdd_x_Kernel = tc.from_numpy(Vdd_x_Kernel).to(GPU)
    print("PyDPFT: Detected dim = {}".format(dim))


def getVint(o, rho):
    v = o.config["Vint"]
    Vx = -(rho ** (1 / 3))
    if v["name"] == "Hartree":
        if o.dim == 1:
            Vint = rho[None, :] * o.VhKernel
        elif o.dim == 2:
            Vint = rho[None, None, :, :] * o.VhKernel
        elif o.dim == 3:
            Vint = rho[None, None, None, :, :, :] * o.VhKernel
    elif v["name"] == "Dipole-x":
        assert o.dim != 1, "Dipole interaction makes no sense in 1D !"
        if o.dim == 2:
            Vint = rho[None, None, :, :] * o.Vdd_x_Kernel
        elif o.dim == 3:
            Vint = rho[None, None, None, :, :, :] * o.Vdd_x_Kernel
    elif v["name"] == "Dipole-p":
        assert o.dim != 1, "Dipole interaction makes no sense in 1D !"
        if o.dim == 2:
            rhoDiff = rho[None, None, :, :] - rho[:, :, None, None]
        elif o.dim == 3:
            rhoDiff = rho[None, None, None, :, :, :] - rho[:, :, :, None, None, None]
        rhoDiff[rhoDiff < 0] = 0
        rhoDiff[rhoDiff > 0] = 1
        Vint = rhoDiff * o.Vdd_p_Kernel
    if o.dim == 1:
        return Vx, v["coef"] * Vint.sum(-1)
    elif o.dim == 2:
        return Vx, v["coef"] * Vint.sum(-1).sum(-1)
    elif o.dim == 3:
        return Vx, v["coef"] * Vint.sum(-1).sum(-1).sum(-1)


def getRhoDPFT(o, V):
    def getRhoN(mu, V):
        muMinusV = mu - V
        muMinusV[muMinusV < 0] = 0
        rho = muMinusV ** (o.dim / 2)
        N = tc.sum(rho) * o.dV
        return rho, N

    muMax = 1
    muMin = tc.min(V)
    trueN = o.config["rho"]["N"]
    while getRhoN(muMax, V)[1] < trueN:
        muMax = muMax * 2
    for i in range(o.config["loop"]["Imax"]):
        muMid = (muMax + muMin) / 2
        rho, N = getRhoN(muMid, V)
        if N > trueN:
            muMax = muMid
        else:
            muMin = muMid
        if 1 - muMin / muMax < o.config["loop"]["precision"]:
            break
    return rho, N


class PyDPFTclass(tc.nn.Module):
    def __init__(self, config):
        super(PyDPFTclass, self).__init__()
        self.config = config
        initVariables(self)

    def forward(self, Vext):  # self consistent loop
        l = self.config["loop"]
        rho = tc.zeros(self.xx.shape).to(GPU)
        Vext = tc.from_numpy(Vext).to(GPU)
        converged = False
        print("PyDPFT: Starting the self consistent loop")
        start = time.time()
        for i in range(l["Imax"]):
            Vx, Vint = getVint(self, rho)
            oldRho = rho
            rho, N = getRhoDPFT(self, Vx + Vint + Vext)
            rho = (1 - l["mix"]) * oldRho + l["mix"] * rho
            if tc.mean(tc.abs(oldRho - rho)) < l["precision"]:
                timeTaken = time.time() - start
                converged = True
                break
            if i == l["Imax"] - 1:
                timeTaken = time.time() - start
            tc.cuda.empty_cache()
        if converged:
            print(
                "PyDPFT: Converged after {} iterations in {} seconds!".format(
                    i, timeTaken
                )
            )
        else:
            print("PyDPFT: NOT Converged after {} seconds!".format(timeTaken))
        return Vx.cpu().numpy(), Vint.cpu().numpy(), rho.cpu().numpy(), N.cpu().numpy()


def PyDPFT(config):
    PyDPFT = PyDPFTclass(config)
    if tc.cuda.device_count() > 1:
        PyDPFT = tc.nn.DataParallel(PyDPFT)
    PyDPFT.to(GPU)
    print("PyDPFT: Using {} GPUs !".format(tc.cuda.device_count()))
    return PyDPFT

#=========================

def plot1D(PyDPFT, Vx, Vint, rho):
    plt.figure(dpi=200, figsize=(4, 4))
    ax1 = plt.subplot(221)
    ax1.title.set_text("Vx")
    ax2 = plt.subplot(222)
    ax2.title.set_text("Vint")
    ax3 = plt.subplot(223)
    ax3.title.set_text("rho")
    ax1.plot(PyDPFT.x, Vx)
    ax2.plot(PyDPFT.x, Vint)
    ax3.plot(PyDPFT.x, rho)
    plt.tight_layout()
    plt.show()


def plot2D(PyDPFT, Vx, Vint, rho):
    plt.figure(dpi=200, figsize=(4, 4))
    ax1 = plt.subplot(221)
    ax1.title.set_text("Vx")
    ax2 = plt.subplot(222)
    ax2.title.set_text("Vint")
    ax3 = plt.subplot(223)
    ax3.title.set_text("rho")
    y0 = int(PyDPFT.config["space"]["y"][2] / 2)
    ax4 = plt.subplot(224)
    ax4.title.set_text("rho, y={y:.2f}".format(y=PyDPFT.y[y0]))
    resolution = 30
    ax1.contourf(PyDPFT.x, PyDPFT.y, Vx, resolution)
    ax2.contourf(PyDPFT.x, PyDPFT.y, Vint, resolution)
    ax3.contourf(PyDPFT.x, PyDPFT.y, rho, resolution)
    ax4.plot(PyDPFT.x, rho[:][y0])
    plt.tight_layout()
    plt.show()


def plot3D(PyDPFT, Vx, Vint, rho):
    plt.figure(dpi=200, figsize=(4, 4))
    ax11 = plt.subplot(331)
    ax11.title.set_text("Vx x=0")
    ax12 = plt.subplot(332)
    ax12.title.set_text("Vx y=0")
    ax13 = plt.subplot(333)
    ax13.title.set_text("Vx z=0")

    ax21 = plt.subplot(334)
    ax21.title.set_text("Vint x=0")
    ax22 = plt.subplot(335)
    ax22.title.set_text("Vint y=0")
    ax23 = plt.subplot(336)
    ax23.title.set_text("Vint z=0")

    ax31 = plt.subplot(337)
    ax31.title.set_text("rho x=0")
    ax32 = plt.subplot(338)
    ax32.title.set_text("rho y=0")
    ax33 = plt.subplot(339)
    ax33.title.set_text("rho z=0")

    x0 = int(PyDPFT.config["space"]["x"][2] / 2)
    y0 = int(PyDPFT.config["space"]["y"][2] / 2)
    z0 = int(PyDPFT.config["space"]["z"][2] / 2)

    resolution = 30
    ax11.contourf(PyDPFT.y, PyDPFT.z, Vx[x0, :, :], resolution)
    ax12.contourf(PyDPFT.x, PyDPFT.z, Vx[:, y0, :], resolution)
    ax13.contourf(PyDPFT.x, PyDPFT.y, Vx[:, :, z0], resolution)

    ax21.contourf(PyDPFT.y, PyDPFT.z, Vint[x0, :, :], resolution)
    ax22.contourf(PyDPFT.x, PyDPFT.z, Vint[:, y0, :], resolution)
    ax23.contourf(PyDPFT.x, PyDPFT.y, Vint[:, :, z0], resolution)

    ax31.contourf(PyDPFT.y, PyDPFT.z, rho[x0, :, :], resolution)
    ax32.contourf(PyDPFT.x, PyDPFT.z, rho[:, y0, :], resolution)
    ax33.contourf(PyDPFT.x, PyDPFT.y, rho[:, :, z0], resolution)
    plt.tight_layout()
    plt.show()


def plot(PyDPFT, Vx, Vint, rho):
    if PyDPFT.dim == 1:
        plot1D(PyDPFT, Vx, Vint, rho)
    elif PyDPFT.dim == 2:
        plot2D(PyDPFT, Vx, Vint, rho)
    elif PyDPFT.dim == 3:
        plot3D(PyDPFT, Vx, Vint, rho)
