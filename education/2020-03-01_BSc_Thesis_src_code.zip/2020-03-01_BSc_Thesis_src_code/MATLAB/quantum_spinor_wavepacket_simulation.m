
%%%%%%%%%%%%%% Below is parameters definition zone %%%%%%%%%%%
    global N  mid  kz_mid  a  h  m    t  C1 C2 C3 C4     diag_ind_1  diag_ind_2  diag_ind_A   amp
    global I z_p1 z_p2 z_p3 z_p4 R  mu_0  S
    N = 41;           mid = (N+1)/2;         kz_mid = 80;  
    a = 0.5;            h = 1;             m = 1;       t = 0.01;      
    diag_ind_1 = 1;      diag_ind_2  = 1;   diag_ind_A = 0;   amp = 1;
    dr = a/2.5;    z_mid =-180;
    S = 0.7 : 0.2 : 1.3;        NS = length(S);
    z_p1=-20; z_p2=-20; z_p3=20; z_p4=20;    mu_0=1;
    ratio=0;
    I1 = 2e5; I2 = ratio*I1;  
    R1 = 60;   R2 = ratio*R1;
                          % best parameters: a = 1; dr = a/2.5;  N = 61;
	C1 = -1i  /(6*h)   *t  ;
	C2 = -1i*h/(4*m)   *t  ;
	C3 = -1i*2/(3*h)   *t  ;
	C4 =  1i  /(72*m*h)*(t^3);
   
%%%%%%%%%%%%%%%%%%%%%  Below is main function zone  %%%%%%%%%%%%%%
   initial_animate(I1,I2,R1,R2);
 
   for ns = 1:1:NS
    dr = a/2;    z_mid =-180;
    [X,Y,Z,z,KX,KY,KZ,k0r,ksq] = create_space(dr,z_mid);
    psi0 = (2*pi)^(-3/4) * a^(-3/2) .* exp( -(X.^2+Y.^2+(Z-z_mid).^2)/(4*a^2) ) .* exp(1i*kz_mid*(Z-z_mid));
    psi9 = psi0;  psi11 = psi0;      
    change_index =1;   
    diag_ind_i = 1;
    
    for T = t:t:400*t
           diag_ind_1 = 1;      diag_ind_2  = 1;
           diag_ind_As(diag_ind_i ) = diag_ind_A;   diag_ind_i = diag_ind_i + 1;  diag_ind_A = 0;
           
		    %%%%%% update space  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            if  change_index == 1
			    [X,Y,Z,z,KX,KY,KZ,k0r,ksq] = create_space(dr,z_mid);
            end
            
            [Bx,By,Bz] = get_B_field(X,Y,Z,I1,I2,R1,R2);
            [Vs,Ps,PIs , V2s,P2s,P2Is ] = get_potential(Bx,By,Bz,dr);           
            [psi9,psi11] = timeOperator(psi9,psi11,Vs,Ps,PIs , V2s,P2s,P2Is,  dr,k0r,ksq);
            
            animate(Bx,Bz,psi9,psi11,X,Y,Z);	
            %%%%%% automatic_camera %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
            [dr,z_mid,psi9, psi11,change_index ] = automatic_camera( dr, z_mid, psi9, psi11 );		
     end   
  
   end
   
%%%%%%%%%%%%%%%%%%%%%% Below is function definition zone %%%%%%%%%%%%%%%%%%%%%% 
    function initial_animate(I1,I2,R1,R2)
         Z = -200:1:200;
        [~,~,Bz] = get_B_field(0,0,Z,I1,I2,R1,R2);
             subplot(2,4,7);
              plot(Z,Bz);
              title('Bz Z, XY fixed, all')
              xlabel('z')
         
    end
    
    
    function animate(Bx,Bz,psi9,psi11,X,Y,Z)
        global mid   N 
            for i=1:1:N
                for j=1:1:N
                    for k = 1:1:N 
                        XY_x(i,j) = X(i,j,mid);  % z fixed
                        XY_y(i,j) = Y(i,j,mid);  % z fixed
                        YZ_y(j,k) = Y(mid,j,k);  % x fixed
                        YZ_z(j,k) = Z(mid,j,k);  % x fixed
                        z(k) = Z(mid,mid,k);
                        
                        psi9_XY(i,j) = abs( psi9(i,j,mid) );  % z fixed
                        psi9_YZ(j,k) = abs( psi9(mid,j,k) );  % x fixed
                        psi9_Z(k) = abs( psi9(mid,mid,k) );  % x,y fixed
                        psi11_Z(k) = abs( psi11(mid,mid,k) )+0.1;  % x,y fixed
                        %psi_diff_XY(i,j) = abs( psi11(i,j,mid) - psi9(i,j,mid) );  % z fixed
                        %psi_diff_YZ(j,k) = abs( psi11(mid,j,k) - psi9(mid,j,k) );  % x fixed
                        Bz_XY(i,j) = Bz(i,j,mid) ;  % z fixed
                        Bz_YZ(j,k) = Bz(mid,j,k) ;  % x fixed
                        Bz_Z(k) = Bz(mid,mid,k);  % x,y fixed
                        %Bx_XY(i,j) = Bx(i,j,mid) ;  % z fixed
                        %Bx_YZ(j,k) = Bx(mid,j,k) ;  % x fixed 
                    end
                end
            end
            subplot(2,4,1);
              surf(XY_x,XY_y,psi9_XY);
              title('psi9 XY, Z fixed')
              xlabel('x')
              ylabel('y')
            subplot(2,4,2);
              surf(YZ_y,YZ_z,psi9_YZ);
              title('psi9 YZ, X fixed')
              xlabel('y')
              ylabel('z')
            
            %{  
            subplot(2,4,3);
              surf(XY_x,XY_y,psi_diff_XY);
              title('psi difference XY, Z fixed')
              xlabel('x')
              ylabel('y')
            subplot(2,4,4);
              surf(YZ_y,YZ_z,psi_diff_YZ);
              title('psi difference YZ, X fixed')
              xlabel('y')
              ylabel('z')
             %}
             subplot(2,4,3);
                plot(z,psi9_Z);
                title('wavefunction modulus')
                %axis([z(1) z(N) 0 amp])
                hold on
                  plot(z,psi11_Z);   
                hold off
             
            subplot(2,4,5);
              surf(XY_x,XY_y,Bz_XY);
              title('Bz XY, Z fixed')
              xlabel('x')
              ylabel('y')
            subplot(2,4,6);
              surf(YZ_y,YZ_z,Bz_YZ);
              title('Bz YZ, X fixed')
              xlabel('y')
              ylabel('z')
            %{  
            subplot(3,2,5);
              surf(XY_x,XY_y,Bx_XY);
              title('Bx XY, Z fixed')
              xlabel('x')
              ylabel('y')
            subplot(3,2,6);
              surf(YZ_y,YZ_z,Bx_YZ);
              title('Bx YZ, X fixed')
              xlabel('y')
              ylabel('z')
            %}
            
            subplot(2,4,8);
              plot(z,Bz_Z);
              title('Bz Z, XY fixed')
              %axis([z(1) z(N) -1000 1000])
              xlabel('z')
              
              
            drawnow

    end 


    function [X,Y,Z,z,KX,KY,KZ,k0r,ksq] = create_space(dr,z_mid)          
        global  N  kz_mid  mid 
        dk = 2*pi / ( N * dr );
        for n=1:1:N
            x(n)  = ( n-mid ) * dr;
            kx(n) = ( n-mid ) * dk;
        end
        z  =  x +  z_mid;  
        kz = kx + kz_mid;
   
        for i=1:1:N
            for j=1:1:N
                for k = 1:1:N
                   X(i,j,k) = x(i);   Y(i,j,k) = x(j);     Z(i,j,k)= z(k);
                  KX(i,j,k) =kx(i);  KY(i,j,k) =kx(j);    KZ(i,j,k)=kz(k);
                end
            end
        end
        k0r = kx(1)*(X+Y) + kz(1)*Z;    ksq = KX.^2 + KY.^2 + KZ.^2;
    end
    % DONE
    
   function [Bx,By,Bz] = magnetic_field_current_loop(X,Y,Z,I,z_p,R)
        global mu_0      %permeability of free space
        rho = ( X.^2 + Y.^2 ).^(1/2); 
        M = 4*R.*rho ./ ( (rho+R).^2+(Z-z_p).^2 ) ; %parameter of Elliptical integral
        K = pi/2 + pi/8*M + 9*pi/128*M.^2;         %K elliptical function
        E = pi/2 - pi/8*M - 3*pi/128*M.^2;         %E elliptical function
        %[K,E] = ellipke(M);
        B_rho = mu_0*I./(2*pi*rho) .* (Z-z_p) .* ( (rho+R).^2+(Z-z_p).^2 ).^(-1/2) .* (-K+E.*( rho.^2+R.^2+(Z-z_p).^2 )./( (rho-R).^2+(Z-z_p).^2 )    ) ;    	
        Bz    = mu_0*I./(2*pi)                .* ( (rho+R).^2+(Z-z_p).^2 ).^(-1/2) .* ( K-E.*( rho.^2-R.^2+(Z-z_p).^2 )./( (rho-R).^2+(Z-z_p).^2 )    ) ;      
        Bx = B_rho .* X ./ rho; 
        By = B_rho .* Y ./ rho;
        Bx(isnan(Bx)) = 0 ;   
		By(isnan(By)) = 0 ;   
		Bz(isnan(Bz)) = 0 ;
    end
    % DONE
    
    
    function [Bx,By,Bz] = get_B_field(X,Y,Z,I1,I2,R1,R2)
        global  z_p1 z_p2 z_p3 z_p4  
        [Bx1,By1,Bz1] = magnetic_field_current_loop(X,Y,Z,I1,z_p1,R1); %first coil
        [Bx2,By2,Bz2] = magnetic_field_current_loop(X,Y,Z,I2,z_p2,R2); 
        [Bx3,By3,Bz3] = magnetic_field_current_loop(X,Y,Z,-I2,z_p3,R2);
        [Bx4,By4,Bz4] = magnetic_field_current_loop(X,Y,Z,-I1,z_p4,R1); 
        Bx=Bx1+Bx2+Bx3+Bx4;   By=By1+By2+By3+By4;   Bz=Bz1+Bz2+Bz3+Bz4;
    end
    
    function [DVsq11,DVsq12,DVsq21,DVsq22] = get_DVsq(V11,V12,V21,V22,dr)     
        [DV11x,DV11y,DV11z] = gradient(V11);  
        DV11x =DV11x / dr ;    DV11y =DV11y / dr ;  DV11z =DV11z / dr ;
        
        [DV12x,DV12y,DV12z] = gradient(V12);  
        DV12x =DV12x / dr ;    DV12y =DV12y / dr ;  DV12z =DV12z / dr ;
        
        [DV21x,DV21y,DV21z] = gradient(V21);  
        DV21x =DV21x / dr ;    DV21y =DV21y / dr ;  DV21z =DV21z / dr ;
        
        [DV22x,DV22y,DV22z] = gradient(V22);  
        DV22x =DV22x / dr ;    DV22y =DV22y / dr ;  DV22z =DV22z / dr ;
        
        DVsq11 = (DV11x .* DV11x + DV11y .* DV11y + DV11z .* DV11z )+(DV12x .* DV21x + DV12y .* DV21y + DV12z .* DV21z );
        DVsq12 = (DV11x .* DV12x + DV11y .* DV12y + DV11z .* DV12z )+(DV12x .* DV22x + DV12y .* DV22y + DV12z .* DV22z );
        DVsq21 = (DV21x .* DV11x + DV21y .* DV11y + DV21z .* DV11z )+(DV22x .* DV21x + DV22y .* DV21y + DV22z .* DV21z );
        DVsq22 = (DV21x .* DV12x + DV21y .* DV12y + DV21z .* DV12z )+(DV22x .* DV22x + DV22y .* DV22y + DV22z .* DV22z );
    end
	% DONE
    
    function [Vs,Ps,PIs , V2s,P2s,P2Is ] = get_potential(Bx,By,Bz,dr)
        global N   diag_ind_1      diag_ind_2    DVsq11  DVsq12   DVsq21   DVsq22  V11  V12 V21 V22
        V11 =  Bz;  
	    V12 =  Bx-1i*By ;  
	    V21 =  Bx+1i*By ;  
	    V22 = -Bz;
		
        [DVsq11,DVsq12,DVsq21,DVsq22] = get_DVsq(V11,V12,V21,V22,dr);
        for i=1:1:N
            for j=1:1:N
                for k=1:1:N
                    V_not_diag = [ V11(i,j,k)    V12(i,j,k)   ;  V21(i,j,k)    V22(i,j,k)  ];
                    if ~isequal(V_not_diag , zeros(2,2) )
                        [P,V] = eig(V_not_diag);   %[P,V] = eig(A) , A = PVP^-1.
                        Vs(:,:,i,j,k) =  V; 
                       VIs(:,:,i,j,k) =  inv(V); 					
					    Ps(:,:,i,j,k) =  P;
				       PIs(:,:,i,j,k) =  inv(P);
                    else 
                        diag_ind_1 = 0;  
                        Vs(:,:,i,j,k) =  zeros(2,2); 
                       VIs(:,:,i,j,k) =  zeros(2,2); 					
					    Ps(:,:,i,j,k) =  eye(2);
				       PIs(:,:,i,j,k) =  eye(2);
                    end
 
					DVsq_not_diag = [DVsq11(i,j,k) DVsq12(i,j,k) ; DVsq21(i,j,k) DVsq22(i,j,k)];
                    if ~isequal(DVsq_not_diag , zeros(2,2))
                        [DPsq,DVsq] = eig(DVsq_not_diag);   %[P,V] = eig(A) , A = PVP^-1.    
                        V2s(:,:,i,j,k) = DVsq;
				       V2Is(:,:,i,j,k) = inv(DVsq);
                        P2s(:,:,i,j,k) = DPsq;
				       P2Is(:,:,i,j,k) = inv(DPsq);
                    else   
                         diag_ind_2 = 0; 
                        V2s(:,:,i,j,k) = zeros(2,2);
				       V2Is(:,:,i,j,k) = zeros(2,2);
                        P2s(:,:,i,j,k) = eye(2);
				       P2Is(:,:,i,j,k) = eye(2);
                    end
                end
            end
        end

    end
	% DONE
   
    function [psi9,psi11] = timeOperator(psi9,psi11,Vs,Ps,PIs , V2s,P2s,P2Is,  dr,k0r,ksq)
        global  C1  C2  C3  C4 N    diag_ind_1    diag_ind_2    diag_ind_A
        for i=1:1:N
            for j=1:1:N
                for k=1:1:N
                    if   diag_ind_1 == 1
                        diag_ind_A = 1;
                       %%% test begins %%%
                         psi9temp(i,j,k) = psi9(i,j,k); 
                        psi11temp(i,j,k) = psi11(i,j,k);
                       %%% test ends %%%
                        
                       psi(:,i,j,k) = Ps(:,:,i,j,k) * (expm(C1 * Vs(:,:,i,j,k)) *  (PIs(:,:,i,j,k) * [psi9(i,j,k) ; psi11(i,j,k)] )) ;  
                       psi9(i,j,k)  = psi(1,i,j,k) * ( dr / sqrt(2*pi) )^3 * exp(-1i * k0r(i,j,k) ); 
                       psi11(i,j,k) = psi(2,i,j,k) * ( dr / sqrt(2*pi) )^3 * exp(-1i * k0r(i,j,k) );
                    else 
                       
                       psi9(i,j,k)  = psi9(i,j,k)  * ( dr / sqrt(2*pi) )^3 * exp(-1i * k0r(i,j,k) ); 
                       psi11(i,j,k) = psi11(i,j,k) * ( dr / sqrt(2*pi) )^3 * exp(-1i * k0r(i,j,k) );
                    end 
                end
            end
        end

        psi9  =ifftn( fftn(psi9) .* exp(C2 * ksq ) );  
        psi11 =ifftn( fftn(psi11).* exp(C2 * ksq ) ); 
        
		%%%%%%%%%%%  MIDDLE PART BEGINS  %%%%%%%%%%%%
        for i=1:1:N
            for j=1:1:N
                for k=1:1:N
                    if   diag_ind_1 ==1
                       psi(:,i,j,k) = Ps(:,:,i,j,k) * (expm(C3 * Vs(:,:,i,j,k)) *  (PIs(:,:,i,j,k) * [psi9(i,j,k) ; psi11(i,j,k)] )) ;  
                       psi9(i,j,k)  = psi(1,i,j,k);
                       psi11(i,j,k) = psi(2,i,j,k);
                    end 
                end
            end
        end
        for i=1:1:N
            for j=1:1:N
                for k=1:1:N
                    if   diag_ind_2 == 1 
                       psi(:,i,j,k) = P2s(:,:,i,j,k) * (expm(C4 * V2s(:,:,i,j,k)) *  (P2Is(:,:,i,j,k) * [psi9(i,j,k) ; psi11(i,j,k)] )) ;  
                       psi9(i,j,k)  = psi(1,i,j,k); 
                       psi11(i,j,k) = psi(2,i,j,k);
                    end 
                end
            end
        end
        %%%%%%%%%%%  MIDDLE PART ENDS  %%%%%%%%%%%%
        
        psi9  =ifftn( fftn(psi9) .* exp(C2 * ksq ) );  
        psi11 =ifftn( fftn(psi11).* exp(C2 * ksq ) );
        
        for i=1:1:N
            for j=1:1:N
                for k=1:1:N
                    if   diag_ind_1 == 1 
                       psi(:,i,j,k) = Ps(:,:,i,j,k) * (expm(C1 * Vs(:,:,i,j,k)) *  (PIs(:,:,i,j,k) * [psi9(i,j,k) ; psi11(i,j,k)] )) ;  
                       psi9(i,j,k)  = psi(1,i,j,k) / ( dr / sqrt(2*pi) )^3 / exp(-1i * k0r(i,j,k) ); 
                       psi11(i,j,k) = psi(2,i,j,k) / ( dr / sqrt(2*pi) )^3 / exp(-1i * k0r(i,j,k) );
                    else 
                       psi9(i,j,k)  = psi9(i,j,k)  / ( dr / sqrt(2*pi) )^3 / exp(-1i * k0r(i,j,k) ); 
                       psi11(i,j,k) = psi11(i,j,k) / ( dr / sqrt(2*pi) )^3 / exp(-1i * k0r(i,j,k) );
                    end 
                end
            end
        end
    end 
    % DONE
    
    
    
    
    
   
    function [dr,z_mid,psi9, psi11,change_index ] = automatic_camera( dr, z_mid, psi9, psi11 )
        global   N   mid 
        change_index = 0;  
      
        PSI = abs( psi9)+abs(psi11) ;
	  
        for n = 1:1:N
            PSIZ(n) = PSI( mid, mid, n);
        end
	  
        rn = 1:1:N;
        [peaks_z,locations_z,widths_z,~] = findpeaks(PSIZ,rn);
        [~, index_z] = max(peaks_z);
      
        if locations_z(index_z) ~= mid 
            for i =1:1:N
                for j =1:1:N
                    for k=1:1:N
                        if k + ( locations_z(index_z)-mid) <= N  &&  k + ( locations_z(index_z)-mid) >= 1
                             psi9new(i,j,k) = psi9 (i,j,k+( locations_z(index_z)-mid));
					    	psi11new(i,j,k) = psi11(i,j,k+( locations_z(index_z)-mid));
                        else
                             psi9new(i,j,k) = 0;
						    psi11new(i,j,k) = 0;
                        end
                    end
                end
            end 
		    z_mid = z_mid + (  locations_z(index_z) - mid) * dr;
            change_index = 1;
        else 
	        psi9new  =  psi9  ;
		    psi11new =  psi11 ;
        end
      
        
           for n = 1:1:N
               PSIX(n) = PSI(n ,mid , mid );
           end 
           [~,~,widths_x,~] = findpeaks(PSIX,rn);
     
   	       maxwidth = 2 * max( [widths_x , widths_z(index_z) ]);
      
           if maxwidth >= mid  
               for i=1:1:N
                   for j=1:1:N
                       for k= 1:1:N
                           if  mid + 2*(i-mid)<=N && mid + 2*(i-mid)>=1    &&     mid + 2*(j-mid)<=N && mid + 2*(j-mid)>=1    &&    mid + 2*(k-mid)<=N && mid + 2*(k-mid)>=1   
                                psi9new2(i,j,k) =  psi9new( mid + 2*(i-mid),mid + 2*(j-mid),mid + 2*(k-mid));
			   			       psi11new2(i,j,k) = psi11new( mid + 2*(i-mid),mid + 2*(j-mid),mid + 2*(k-mid));
                           else
                                psi9new2(i,j,k) =  0;
					           psi11new2(i,j,k) =  0;
                           end
                       end
                   end
               end
		       dr = dr*2;
		       psi9  = psi9new2;
		       psi11 =psi11new2;
           else 
               psi9  = psi9new;
		       psi11 =psi11new;
           end

    end
	% DONE

    function [dr,z_mid,psi9, psi11,change_index ] = automatic_camera2( dr, z_mid, psi9, psi11 )
        global   N   mid 
        change_index = 0;  
      
        PSI = abs( psi9)+abs(psi11) ;
	  
        for n = 1:1:N
            PSIZ(n) = PSI( mid, mid, n);
        end
	  
        rn = 1:1:N;
        [peaks_z,locations_z,widths_z,~] = findpeaks(PSIZ,rn);
        [~, index_z] = max(peaks_z);
      
        if locations_z(index_z) ~= mid 
            for i =1:1:N
                for j =1:1:N
                    for k=1:1:N
                        if k + ( locations_z(index_z)-mid) <= N  &&  k + ( locations_z(index_z)-mid) >= 1
                             psi9new(i,j,k) = psi9 (i,j,k+( locations_z(index_z)-mid));
					    	psi11new(i,j,k) = psi11(i,j,k+( locations_z(index_z)-mid));
                        else
                             psi9new(i,j,k) = 0;
						    psi11new(i,j,k) = 0;
                        end
                    end
                end
            end 
		    z_mid = z_mid + (  locations_z(index_z) - mid) * dr;
            change_index = 1;
        else 
	        psi9new  =  psi9  ;
		    psi11new =  psi11 ;
        end
      
        
           

    end
	% DONE

   