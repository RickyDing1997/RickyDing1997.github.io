
   global N  mid  kz_mid  a  
   global I1 I2  R1 R2 z_p1 z_p2 z_p3 z_p4   mu_0   
    a = 1;
    N = 51;           mid = (N+1)/2;         kz_mid = 80;
    mu_0=1;
    ratio=5;
    I1 = 1e3; I2 = ratio*I1;  
    R1 = 100;   R2 = ratio*R1;
    z_p1=-3; z_p2=-3; z_p3=8; z_p4=8;      
    
 

slidervalue;

function slidervalue
% Create figure window and components
fig = uifigure('Position',[100 100 350 275]);
cg = plot(3);
sld = uislider(fig,...
    'Position',[100 75 120 3],...
    'ValueChangedFcn',@(sld,event) updateGauge(sld,cg));
end

% Create ValueChangedFcn callback
function updateGauge(sld,cg)
    quiver1(sld.Value/20.0);
end
   
%%%%%%%%%%%%%%%%%%%%%  Below is main function zone  %%%%%%%%%%%%%%
    function quiver1(ratio)
       global N  mid  a  I1 R1
       R2=3;
       dr = a;  z_mid =0;
       [X,Y,Z,z,~,~,~,~,~] = create_space(dr,z_mid);
       
        I2 = ratio*I1;  
        R2 = ratio*R1;
       [~,By,Bz] = get_B_field(X,Y,Z,I1,I2,R1,R2);

        for j=1:1:N
            for k=1:1:N
                Bzz(j,k)=Bz(mid,j,k);
                zz(j,k)=Z(mid,j,k); 
                Byy(j,k)=By(mid,j,k);
                yy(j,k)=Y(mid,j,k); 
                f(k)=Bz(mid,mid,k);
            end
        end
        
        h1 = subplot(2,1,1);
        set(h1, 'OuterPosition', [0.02,0.5, 0.3, 0.5]);
           plot(z,f)
           axis([-10 10 -1000 1000])
           
        h2 = subplot(2,1,2); 
        set(h2, 'OuterPosition', [0.23,0.05, 0.84, 0.9]);
           quiver(zz,yy,Bzz,Byy) 
        
    end
    % DONE
%%%%%%%%%%%%%%%%%%%%%% Below is function definition zone %%%%%%%%%%%%%%%%%%%%%% 
    function [X,Y,Z,z,KX,KY,KZ,k0r,ksq] = create_space(dr,z_mid)          
        global  N  kz_mid  mid 
        dk = 2*pi / ( N * dr );
        for n=1:1:N
            x(n)  = ( n-mid ) * dr;
            kx(n) = ( n-mid ) * dk;
        end
        z  =  x +  z_mid;  
        kz = kx + kz_mid;
   
        for i=1:1:N
            for j=1:1:N
                for k = 1:1:N
                   X(i,j,k) = x(i);   Y(i,j,k) = x(j);     Z(i,j,k)= z(k);
                  KX(i,j,k) =kx(i);  KY(i,j,k) =kx(j);    KZ(i,j,k)=kz(k);
                end
            end
        end
        k0r = kx(1)*(X+Y) + kz(1)*Z;    ksq = KX.^2 + KY.^2 + KZ.^2;
    end
    % DONE
    
    function [Bx,By,Bz] = magnetic_field_current_loop(X,Y,Z,I,z_p,R)
        global mu_0      %permeability of free space
        rho = ( X.^2 + Y.^2 ).^(1/2); 
        M = 4*R.*rho ./ ( (rho+R).^2+(Z-z_p).^2 ) ; %parameter of Elliptical integral
        K = pi/2 + pi/8*M + 9*pi/128*M.^2;         %K elliptical function
        E = pi/2 - pi/8*M - 3*pi/128*M.^2;         %E elliptical function
        %[K,E] = ellipke(M);
        B_rho = mu_0*I./(2*pi*rho) .* (Z-z_p) .* ( (rho+R).^2+(Z-z_p).^2 ).^(-1/2) .* (-K+E.*( rho.^2+R.^2+(Z-z_p).^2 )./( (rho-R).^2+(Z-z_p).^2 )    ) ;    	
        Bz    = mu_0*I./(2*pi)                .* ( (rho+R).^2+(Z-z_p).^2 ).^(-1/2) .* ( K-E.*( rho.^2-R.^2+(Z-z_p).^2 )./( (rho-R).^2+(Z-z_p).^2 )    ) ;      
        Bx = B_rho .* X ./ rho; 
        By = B_rho .* Y ./ rho;
        Bx(isnan(Bx)) = 0 ;   
		By(isnan(By)) = 0 ;   
		Bz(isnan(Bz)) = 0 ;
    end
    % DONE
    
    function [Bx,By,Bz] = get_B_field(X,Y,Z,I1,I2,R1,R2)
        global  z_p1 z_p2 z_p3 z_p4  
        [Bx1,By1,Bz1] = magnetic_field_current_loop(X,Y,Z,I1,z_p1,R1); %first coil
        [Bx2,By2,Bz2] = magnetic_field_current_loop(X,Y,Z,I2,z_p2,R2); 
        [Bx3,By3,Bz3] = magnetic_field_current_loop(X,Y,Z,-I2,z_p3,R2);
        [Bx4,By4,Bz4] = magnetic_field_current_loop(X,Y,Z,-I1,z_p4,R1); 
        Bx=Bx1+Bx2+Bx3+Bx4;   By=By1+By2+By3+By4;   Bz=Bz1+Bz2+Bz3+Bz4;
    end
    